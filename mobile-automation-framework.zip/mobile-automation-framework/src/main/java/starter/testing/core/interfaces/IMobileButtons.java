package starter.testing.core.interfaces;

import io.appium.java_client.AppiumDriver;

public interface IMobileButtons {

    public void pressHomeButton(AppiumDriver<?> driver);

}
